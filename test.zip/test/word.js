let user = prompt("Enter a text --> ");

function count_space(user) {
  let i = 0;
  let count = 0;
  while (i < user.length) {
    if (user[i] == " ") {
      count++;
    }
    i++;
  }

  return count;
}

function sentence_count(user) {
  let i = 0;
  let count = 0;
  while (i < user.length) {
    if (user[i] != " ") {
      count++;
    }
    i++;
  }

  return count;
}

function count_of_upercase(user) {
  let arr_up = [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
  ];
  let i = 0;
  while (i < user.length) {
    i++;
  }
}

function count_of_lowercase(user) {
  let arr_lw = [
    "a",
    "b",
    "c",
    "d",
    "e",
    "f",
    "g",
    "h",
    "i",
    "j",
    "k",
    "l",
    "m",
    "n",
    "o",
    "p",
    "q",
    "r",
    "s",
    "t",
    "u",
    "v",
    "w",
    "x",
    "y",
    "z",
  ];
}

alert("This is count of space -->  ${count_space(user)}");
alert("This is count of letter --> ", sentence_count(user));
